const enumError = {
    ROUTING_ERROR: 1,
    DB_CONNECTION_ERROR: 2,
    AUTH_ERROR: 3,
    PURCHASE_ERROR: 4,
    QUERY_ERROR:5,
    INVALID_DATA:6,
    FILESYSTEM_ERROR: 7,
    UNKNOWN_ERROR: 9,
  };

  export default enumError;